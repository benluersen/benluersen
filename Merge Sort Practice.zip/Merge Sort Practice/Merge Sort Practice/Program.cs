﻿using Merge_Sort_Practice;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Merge_Sort_Practice_Vs_Bubble_Sort_Practice
{
    class Program
    {
        static void Main(string[] args)
        {
            CLI cli = new CLI();
            cli.screenWriter();
        }
    }
}
